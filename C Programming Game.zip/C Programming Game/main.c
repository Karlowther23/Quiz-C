#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#define NUMQ 5

int intro() {
  printf("Welcome to the Quiz.\n");
  printf("There will be 5 questions for you to answer.\n");
  printf("You will recieve your result at the end of the game.\n");
  printf("***All answers are case sensitive. Use captials when necessary***\n");
  printf("\n");
}

int play() {
  FILE * qFile = NULL;
  qFile = fopen("question.txt", "r");
  if (qFile == NULL) {
    printf("File not found\n");
    return 1;
  }
  char c;
  int op = -1;

  char aArray[NUMQ][100];
  for (int i = 0; i < NUMQ; i++) {
    memset(aArray[i], '\0', 100);
  }
  int ap = 0;

  printf("Questions:\n");
  int i;
  while ((c = getc(qFile)) != EOF) {
    if (c == '?') {
      printf("? ");
      c = getc(qFile); // skips space
      i = 0;
      while (c = getc(qFile)) { // add answer to answer array
        if (c == '\n' || c == '\r') {
          break;
        }
        aArray[ap][i++] = c;
      }
      printf("\n");
      ap++;
    } else {
      printf("%c", c);
    }
  }

  int score = 0;
  char ans[100];
  char wrong[NUMQ][100];
  for (int i = 0; i < NUMQ; i++) {
    memset(wrong[i], '\0', 100);
  }
  int wp = 0;

  //int input = 0;
  printf("\nThere are %d questions in the Quiz:\n", NUMQ);

  printf("\nPlease choose a difficulty level:\n");
  for (size_t i = 0; i < 5; i++) {
    printf("Level %d:\n", i + 1);
  }

  int input;
  printf("\nPlease enter Level: \n");
  while (scanf("%d", & input) != 1) {
    printf("\nPlease enter Level: \n");
    while (getchar() != '\n');
  }

  //Level 1
  if (input == 1) {
    printf("**No Hint**\n");
    for (size_t i = 0; i < NUMQ; i++) {
      printf("\nAnswer for Question %d:\n", i + 1);
      printf("?\n");
      scanf("%s", & ans);

      FILE * aFile;
      aFile = fopen("userAnswer.txt", "a");
      fputs("\n", aFile);
      fputs(ans, aFile);
      fclose(aFile);

      if (strcmp(ans, aArray[i]) == 0) {
        score = score + 1;
      } else {
        strcpy(wrong[wp], aArray[i]);
        wp++;
        printf("Incorrect.\n");
      }
    }
    printf("\nTotal Score: %d/%d\n", score, NUMQ);

  }

  //Level 2
  else if (input == 2) {
    printf("**Dashes**\n");
    for (size_t i = 0; i < NUMQ; i++) {
      printf("\nAnswer for Question %d:\n", i + 1);
      for (size_t x = 0; x < strlen(aArray[i]); x++) {
        printf("- ");
      }
      printf("\n");
      scanf("%s", ans);

      FILE * aFile;
      aFile = fopen("userAnswer.txt", "a");
      fputs("\n", aFile);
      fputs(ans, aFile);
      fclose(aFile);

      if (strcmp(ans, aArray[i]) == 0) {
        score = score + 1;
      } else {
        strcpy(wrong[wp], aArray[i]);
        wp++;
        printf("Incorrect.\n");
      }
    }
    printf("\nTotal Score: %d/%d\n", score, NUMQ);
  }

  //Level 3
  else if (input == 3) {
    printf("**First and last shown**\n");
    for (size_t i = 0; i < NUMQ; i++) {
      printf("\nAnswer for Question %d:\n", i + 1);

      for (size_t x = 0; x < strlen(aArray[i]); x++) {

        if (x == 0 || x == strlen(aArray[i]) - 1) {
          printf("%c ", aArray[i][x]);
        } else {
          printf("- ");
        }
      }

      printf("\n");
      scanf("%s", ans);

      FILE * aFile;
      aFile = fopen("userAnswer.txt", "a");
      fputs("\n", aFile);
      fputs(ans, aFile);
      fclose(aFile);

      if (strcmp(ans, aArray[i]) == 0) {
        score = score + 1;
      } else {
        strcpy(wrong[wp], aArray[i]);
        wp++;
        printf("Incorrect.\n");
      }
    }
    printf("\nTotal Score: %d/%d\n", score, NUMQ);
  }

  //Level 4
  else if (input == 4) {
    printf("**Random Dashes**\n");
    for (size_t i = 0; i < NUMQ; i++) {
      printf("\nAnswer for Question %d:\n", i + 1);

      srand(time(NULL));
      int randNum1 = rand() % strlen(aArray[i]);
      int randNum2 = rand() % strlen(aArray[i]);

      while (randNum1 == randNum2) {
        randNum2 = rand() % strlen(aArray[i]);
      }

      for (size_t x = 0; x < strlen(aArray[i]); x++) {
        if (x == randNum1 || x == randNum2) {
          printf("%c ", aArray[i][x]);
        } else {
          printf("- ");
        }
      }
      printf("\n");

      scanf("%s", ans);

      FILE * aFile;
      aFile = fopen("userAnswer.txt", "a");
      fputs("\n", aFile);
      fputs(ans, aFile);
      fclose(aFile);

      if (strcmp(ans, aArray[i]) == 0) {
        score = score + 1;
      } else {
        strcpy(wrong[wp], aArray[i]);
        wp++;
        printf("Incorrect.\n");
      }
    }
    printf("\nTotal Score: %d/%d\n", score, NUMQ);
  }

  //Level 5
  else if (input == 5) {
    printf("**Jumbled**\n");
    for (size_t i = 0; i < NUMQ; i++) {
      printf("\nAnswer for Question %d:\n", i + 1);

      srand(time(NULL));
      int pickPos[strlen(aArray[i])];
      for (size_t i = 0; i < strlen(aArray[i]); i++) {
        pickPos[i] = strlen(aArray[i]);
      }
      int pp = 0;

      for (int x = 0; x < strlen(aArray[i]); x++) {
        int randNum1 = rand() % strlen(aArray[i]); //random num generated at random pos
        int checked = 0; //pos hasnt been checeked
        while (checked == 0) { //while not checked go throught displayed stored pos
          for (int k = 0; k < pp; k++) {
            if (randNum1 == pickPos[k]) { //if the random num is equal to a stored position
              randNum1 = rand() % strlen(aArray[i]); //gen new pos
              k = -1;
              continue; //starts again
            }
          }
          checked = 1;
          pickPos[pp] = randNum1;
          pp++;
        }
        printf("%c ", aArray[i][randNum1]);

      }
      printf("\n");
      scanf("%s", ans);

      FILE * aFile;
      aFile = fopen("userAnswer.txt", "a");
      fputs("\n", aFile);
      fputs(ans, aFile);
      fclose(aFile);

      if (strcmp(ans, aArray[i]) == 0) {
        score = score + 1;
      } else {
        strcpy(wrong[wp], strcat(aArray[i], "\n"));
        wp++;
        printf("Incorrect.\n");
      }
    }
    printf("\nTotal Score: %d/%d\n", score, NUMQ);
  } else {
    printf("TryAgain.\n");
    play();
  }

  //Show answers or not
  printf("\nShow answers:\n");
  printf("\n***Type 'yes' or 'no'***\n");
  char res[10];
  scanf("%s", res);
  if (strcmp(res, "yes") == 0) {
    printf("\n");
    printf("The answers you got wrong:\n");
    for (int i = 0; i < NUMQ; i++) {
      printf(wrong[i]);
      printf("\n");
    }

    printf("\n\n***Would you like to play again?***");
    printf("\n***Type 'yes' or 'no'***\n");

    scanf("%s", res);
    if (strcmp(res, "yes") == 0) {
      main();
    } else {
      printf("\nOkay! See you next time!\n");
      printf("\nYour Total Score: %d/%d\n", score, NUMQ);
    }

  } else if (strcmp(res, "no") == 0) {
    printf("\n\n***Would you like to play again?***");
    printf("\n***Type 'yes' or 'no'***\n");

    scanf("%s", res);
    if (strcmp(res, "yes") == 0) {
      main();
    } else {
      printf("\nOkay! See you next time!\n");
      printf("\nYour Total Score: %d/%d\n", score, NUMQ);
    }
  }

}

//Main
int main() {
  intro();
  play();
}
